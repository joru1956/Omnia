/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
document.write("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
document.write("<link rel='stylesheet' type='text/css' href='zaklad.css'>");
document.write("<meta http-equiv='pragma' content='no-cache'>");



